from django.contrib import admin
from webapp.models import Carousel,product,banner
# Register your models here.
admin.site.register(Carousel)
admin.site.register(product)
admin.site.register(banner)