from django.shortcuts import render
from webapp.models import Carousel,product,banner
import math
# Create your views here.
def home(request):
    obj = Carousel.objects.all()
    products = product.objects.all()
    ban= banner.objects.all()
    n = len(products)
    nslides = n // 5 + math.ceil((n / 5) - (n // 5))
    param = {'obj':obj,'ban':ban,'no_of_slides': nslides,'product':products,'range':range(1,nslides)}
    return render(request,"home/index.html",param)
def post(request, slug):
    Po=product.objects.filter(slug=slug).first()
    context={'po':Po}
    return render(request,'home/post.html',context)
def pro(request):
    return render(request,'home/post.html')