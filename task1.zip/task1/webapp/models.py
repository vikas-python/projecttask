from django.db import models

# Create your models here.
class Carousel(models.Model):
    image_id = models.AutoField
    image= models.ImageField(upload_to="home/images",default="")
class product(models.Model):
    product_id= models.AutoField
    product_name= models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    sale_price = models.IntegerField(default=0)
    desc= models.TextField(max_length=1000)
    pub_date= models.DateField()
    slug = models.CharField(max_length=20)
    image= models.ImageField(upload_to="home/images",default="")


    def __str__(self):
        return self.product_name
class banner(models.Model):
    banner_id = models.AutoField
    banner_img = models.ImageField(upload_to="home/images", default="")